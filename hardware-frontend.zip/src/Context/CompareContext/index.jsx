import { createContext } from 'react';

const CompareContext = createContext();

export default CompareContext;
