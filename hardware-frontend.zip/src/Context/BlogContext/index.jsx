import { createContext } from 'react';

const BlogContext = createContext();

export default BlogContext;
