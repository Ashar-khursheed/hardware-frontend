import { createContext } from 'react';

const BlogIdsContext = createContext();

export default BlogIdsContext;
