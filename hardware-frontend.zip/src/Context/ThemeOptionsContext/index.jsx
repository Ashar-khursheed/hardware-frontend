'use client';
import { createContext } from 'react';

const ThemeOptionContext = createContext();

export default ThemeOptionContext;
