import { createContext } from 'react';

const ZoneContext = createContext();

export default ZoneContext;
