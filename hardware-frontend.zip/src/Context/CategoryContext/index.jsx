import { createContext } from 'react';

const CategoryContext = createContext();

export default CategoryContext;
