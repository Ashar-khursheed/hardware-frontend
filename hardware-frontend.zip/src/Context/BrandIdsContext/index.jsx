import { createContext } from 'react';

const BrandIdsContext = createContext();

export default BrandIdsContext;
