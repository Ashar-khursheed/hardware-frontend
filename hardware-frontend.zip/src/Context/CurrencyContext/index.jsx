import { createContext } from 'react';

const CurrencyContext = createContext();

export default CurrencyContext;
