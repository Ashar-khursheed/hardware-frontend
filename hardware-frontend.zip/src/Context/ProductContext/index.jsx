import { createContext } from 'react';

const ProductIdsContext = createContext();

export default ProductIdsContext;
