import { createContext } from 'react';

const AccountContext = createContext();

export default AccountContext;