import SearchModule from "@/Components/Pages/Search";
import React from "react";

const Search = () => {
  return <SearchModule />;
};

export default Search;
