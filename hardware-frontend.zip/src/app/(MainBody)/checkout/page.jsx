import CheckoutContent from "@/Components/Pages/Checkout";
import React from "react";

const Checkout = () => {
  return <CheckoutContent />;
};

export default Checkout;
