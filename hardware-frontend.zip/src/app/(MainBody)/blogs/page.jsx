import BlogDetail from "@/Components/Blogs/Details";

const BlogDetails = () => {
  return <BlogDetail />;
};

export default BlogDetails;
