import OrderDetailsTracking from "@/Components/Pages/OrderDetails/Index";

const OrderDetails = () => {
  return <OrderDetailsTracking />;
};

export default OrderDetails;
