import TrackingData from "@/Components/Pages/OrderTracking";

const OrderDetails = () => {
  return <TrackingData />;
};

export default OrderDetails;
