import CartContent from "@/Components/Cart";
import React from "react";

const Cart = () => {
  return <CartContent />;
};

export default Cart;
