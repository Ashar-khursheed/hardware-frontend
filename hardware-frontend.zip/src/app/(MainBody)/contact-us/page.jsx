import ContactUsContent from "@/Components/Pages/ContactUs";
import React from "react";

const ContactUs = () => {
  return <ContactUsContent />;
};

export default ContactUs;
