import Offer from "@/Components/Pages/Offer";
import React from "react";

const OffersPage = () => {
  return <Offer />;
};

export default OffersPage;
