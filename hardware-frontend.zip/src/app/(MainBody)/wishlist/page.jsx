import WishlistContent from "@/Components/Pages/Wishlist";
import React from "react";

const Wishlist = () => {
  return <WishlistContent />;
};

export default Wishlist;
