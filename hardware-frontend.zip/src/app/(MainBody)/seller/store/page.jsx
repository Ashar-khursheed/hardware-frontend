"use client";

import SellerStoreContent from "@/Components/Seller/Stores";

const SellerStore = () => {
  return <SellerStoreContent />;
};

export default SellerStore;
