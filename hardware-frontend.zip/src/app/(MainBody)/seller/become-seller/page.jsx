import BecomeSellerContent from "@/Components/Seller/BecomeSeller";

const BecomeSeller = () => {
  return <BecomeSellerContent />;
};

export default BecomeSeller;
