import CompareList from "@/Components/Pages/Compare";
import React from "react";

const Compare = () => {
  return <CompareList />;
};

export default Compare;
