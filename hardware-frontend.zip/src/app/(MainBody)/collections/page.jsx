import CollectionContain from "@/Components/Collection";
import React from "react";

const Collection = () => {
  return <CollectionContain />;
};

export default Collection;
