import AboutUsContent from "@/Components/Pages/AboutUs";
import React from "react";

const AboutUs = () => {
  return <AboutUsContent />;
};

export default AboutUs;
