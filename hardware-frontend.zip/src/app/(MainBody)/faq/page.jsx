import BrowserFaq from "@/Components/Pages/Faq";
import React from "react";

const Faq = () => {
  return <BrowserFaq />;
};

export default Faq;
