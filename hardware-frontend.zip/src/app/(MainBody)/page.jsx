import ActiveTheme from "@/Components/ActiveTheme";

export default function Home() {
  return <ActiveTheme />;
}
