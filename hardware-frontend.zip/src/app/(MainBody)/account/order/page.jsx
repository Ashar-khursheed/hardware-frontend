import AccountOrders from "@/Components/Pages/Account/Orders";
import React from "react";

const AccountOrderComponent = () => {
  return <AccountOrders />;
};

export default AccountOrderComponent;
