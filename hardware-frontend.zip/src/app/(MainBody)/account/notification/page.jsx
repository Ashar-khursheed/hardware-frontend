import AccountNotificationContent from "@/Components/Pages/Account/Notification";
import React from "react";

const AccountNotifications = () => {
  return <AccountNotificationContent />;
};

export default AccountNotifications;
