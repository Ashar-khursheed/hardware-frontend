import AccountDownloads from "@/Components/Pages/Account/Downloads";
import React from "react";

const AccountDownload = () => {
  return <AccountDownloads />;
};

export default AccountDownload;
