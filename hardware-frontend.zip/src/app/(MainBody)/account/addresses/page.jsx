import AccountAddresses from "@/Components/Pages/Account/Addresses";
import React from "react";

const AccountAddressesComponent = () => {
  return <AccountAddresses />;
};

export default AccountAddressesComponent;
