import AccountPoints from "@/Components/Pages/Account/Points";
import React from "react";

const AccountPointComponent = () => {
  return <AccountPoints />;
};

export default AccountPointComponent;
