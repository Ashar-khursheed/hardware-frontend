import AccountRefund from "@/Components/Pages/Account/Refund";
import React from "react";

const AccountRefundComponent = () => {
  return <AccountRefund />;
};

export default AccountRefundComponent;
