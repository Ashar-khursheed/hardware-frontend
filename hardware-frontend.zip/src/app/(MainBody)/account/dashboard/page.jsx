import AccountDashboard from '@/Components/Pages/Account/Dashboard'
import React from 'react'

const AccountDashboardComponent = () => {
  return (
   <AccountDashboard/>
  )
}

export default AccountDashboardComponent