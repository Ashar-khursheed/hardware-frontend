import WalletContent from "@/Components/Pages/Account/Wallet";
import React from "react";

const AccountWalletComponent = () => {
  return <WalletContent />;
};

export default AccountWalletComponent;
