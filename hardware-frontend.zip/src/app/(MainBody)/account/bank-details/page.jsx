import BankDetailsContent from '@/Components/Pages/Account/BankDetails'
import React from 'react'

const AccountBankDetailsComponent = () => {
  return (
  <BankDetailsContent/>
  )
}

export default AccountBankDetailsComponent