// import placeholderImg from '../../../public/assets/images/placeholder/product.png';
export const placeHolderImage = '/assets/images/placeholder/product.png';
